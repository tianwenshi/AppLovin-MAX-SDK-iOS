//
//  MaticooSDK.h
//  MaticooSDK
//
//  Created by root on 2023/5/25.
//

#ifndef MaticooSDK_h
#define MaticooSDK_h

#import "MaticooAds.h"
#import "MATBannerAd.h"
#import "MATNativeAd.h"
#import "MATInteractAd.h"
#import "MATInterstitialAd.h"
#import "MATRewardedVideoAd.h"
#import "MATSplashAd.h"

#endif /* MaticooSDK_h */

