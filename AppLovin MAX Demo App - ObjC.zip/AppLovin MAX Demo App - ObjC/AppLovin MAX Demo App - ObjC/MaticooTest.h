//
//  MaticooTest.h
//  AppLovin MAX Demo App - ObjC
//
//  Created by xuge on 2024/11/7.
//  Copyright © 2024 AppLovin Corporation. All rights reserved.
//

#ifndef MaticooTest_h
#define MaticooTest_h


#define MAT_EXTRA_GPID   @"gpid"
#define MAT_EXTRA_GPID_VALUE   @""

#endif /* MaticooTest_h */
