//
//  ALTextCollectionViewCell.m
//  AppLovin MAX Demo App - ObjC
//
//  Created by Ritam Sarmah on 4/1/22.
//  Copyright © 2022 AppLovin Corporation. All rights reserved.
//

#import "ALTextCollectionViewCell.h"

@implementation ALTextCollectionViewCell

@end
