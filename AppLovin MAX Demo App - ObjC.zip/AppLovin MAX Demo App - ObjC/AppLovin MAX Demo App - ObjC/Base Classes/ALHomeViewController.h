//
//  ALHomeViewController.h
//  DemoApp-ObjC
//
//  Created by Thomas So on 9/4/19.
//  Copyright © 2019 AppLovin Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ALHomeViewController : UITableViewController

@end
