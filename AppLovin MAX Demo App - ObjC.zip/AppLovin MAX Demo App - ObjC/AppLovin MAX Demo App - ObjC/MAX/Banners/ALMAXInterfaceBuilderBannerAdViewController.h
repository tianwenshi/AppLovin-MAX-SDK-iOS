//
//  ALMAXInterfaceBuilderBannerAdViewController.h
//  DemoApp-ObjC
//
//  Created by Andrew Tian on 9/10/19.
//  Copyright © 2019 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ALMAXInterfaceBuilderBannerAdViewController : ALBaseAdViewController

@end

NS_ASSUME_NONNULL_END
