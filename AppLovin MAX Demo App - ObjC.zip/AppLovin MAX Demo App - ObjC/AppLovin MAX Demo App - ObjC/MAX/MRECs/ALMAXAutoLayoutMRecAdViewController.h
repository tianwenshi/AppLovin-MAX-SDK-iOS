//
//  ALMAXAutoLayoutMRecAdViewController.h
//  DemoApp-ObjC
//
//  Created by Andrew Tian on 1/14/20.
//  Copyright © 2020 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ALMAXAutoLayoutMRecAdViewController : ALBaseAdViewController

@end

NS_ASSUME_NONNULL_END
