//
//  ALMAXFrameLayoutMRecAdViewController.h
//  DemoApp-ObjC
//
//  Created by Andrew Tian on 1/23/20.
//  Copyright © 2020 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ALMAXFrameLayoutMRecAdViewController : ALBaseAdViewController

@end

NS_ASSUME_NONNULL_END
