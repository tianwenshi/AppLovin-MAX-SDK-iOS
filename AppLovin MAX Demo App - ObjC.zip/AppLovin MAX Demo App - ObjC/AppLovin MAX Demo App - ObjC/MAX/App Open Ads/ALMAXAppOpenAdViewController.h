//
//  ALMAXAppOpenAdViewController.h
//  AppLovin MAX Demo App - ObjC
//
//  Created by Avi Leung on 2/13/23.
//  Copyright © 2023 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ALMAXAppOpenAdViewController : ALBaseAdViewController

@end

NS_ASSUME_NONNULL_END
