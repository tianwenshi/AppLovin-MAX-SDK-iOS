//
//  ALMAXRewardedAdViewController.h
//  DemoApp-ObjC
//
//  Created by Thomas So on 9/4/19.
//  Copyright © 2019 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ALMAXRewardedAdViewController : ALBaseAdViewController

@end

NS_ASSUME_NONNULL_END
