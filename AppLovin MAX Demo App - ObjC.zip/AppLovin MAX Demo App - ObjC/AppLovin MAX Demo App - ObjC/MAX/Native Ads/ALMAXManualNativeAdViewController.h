//
//  ALMAXManualNativeAdViewController.h
//  AppLovin MAX Demo App - ObjC
//
//  Created by Billy Hu on 1/20/22.
//  Copyright © 2022 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ALMAXManualNativeAdViewController : ALBaseAdViewController

@end

NS_ASSUME_NONNULL_END
