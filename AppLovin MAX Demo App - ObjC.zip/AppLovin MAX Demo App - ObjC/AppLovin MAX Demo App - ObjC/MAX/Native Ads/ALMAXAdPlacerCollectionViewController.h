//
//  ALMAXAdPlacerCollectionViewController.h
//  AppLovin MAX Demo App - ObjC
//
//  Created by Ritam Sarmah on 4/1/22.
//  Copyright © 2022 AppLovin Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ALMAXAdPlacerCollectionViewController : UICollectionViewController

@end

NS_ASSUME_NONNULL_END
