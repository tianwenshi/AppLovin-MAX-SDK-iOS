//
//  ALMAXManualNativeLateBindingAdViewController.h
//  AppLovin MAX Demo App - ObjC
//
//  Created by Billy Hu on 3/8/22.
//  Copyright © 2022 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ALMAXManualNativeLateBindingAdViewController : ALBaseAdViewController

@end

NS_ASSUME_NONNULL_END
