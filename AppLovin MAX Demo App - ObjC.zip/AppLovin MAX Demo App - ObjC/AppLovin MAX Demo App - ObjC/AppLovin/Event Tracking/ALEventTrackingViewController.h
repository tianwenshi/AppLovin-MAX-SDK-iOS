//
//  ALEventTrackingViewController.h
//  iOS-SDK-Demo-ObjC
//
//  Created by Monica on 6/5/17.
//  Copyright © 2017 AppLovin. All rights reserved.
//

#import "ALBaseAdViewController.h"

@interface ALEventTrackingViewController : UITableViewController

@end
