//
//  ALDemoProgrammaticBannerViewController.h
//  iOS-SDK-Demo-ObjC
//
//  Created by Thomas So on 3/5/17.
//  Copyright © 2017 AppLovin. All rights reserved.
//

#import "ALBaseAdViewController.h"

@interface ALDemoProgrammaticBannerViewController : ALBaseAdViewController

@end
