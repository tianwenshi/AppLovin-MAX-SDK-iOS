//
//  ALDemoInterfaceBuilderBannerViewController.h
//  iOS-SDK-Demo-ObjC
//
//  Created by Thomas So on 3/6/17.
//  Copyright © 2017 AppLovin. All rights reserved.
//

#import "ALBaseAdViewController.h"

@interface ALDemoInterfaceBuilderBannerViewController : ALBaseAdViewController

@end
