//
//  ALDemoInterfaceBuilderMRecViewController.h
//  AppLovin MAX Demo App - ObjC
//
//  Created by Nana Amoah on 11/22/21.
//  Copyright © 2021 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

@interface ALDemoInterfaceBuilderMRecViewController : ALBaseAdViewController

@end
