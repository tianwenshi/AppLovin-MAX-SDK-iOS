//
//  ALDemoProgrammaticMRecViewController.h
//  AppLovin MAX Demo App - ObjC
//
//  Created by Nana Amoah on 11/18/21.
//  Copyright © 2021 AppLovin Corporation. All rights reserved.
//

#import "ALBaseAdViewController.h"

@interface ALDemoProgrammaticMRecViewController : ALBaseAdViewController

@end
