//
//  ALDemoRewardedVideosZoneViewController.h
//  iOS-SDK-Demo-ObjC
//
//  Created by Suyash Saxena on 6/19/18.
//  Copyright © 2018 AppLovin. All rights reserved.
//

#import "ALBaseAdViewController.h"

@interface ALDemoRewardedVideosZoneViewController : ALBaseAdViewController

@end
