//
//  ALDemoRewardedVideosViewController.h
//  iOS-SDK-Demo
//
//  Created by Thomas So on 9/23/15.
//  Copyright © 2015 AppLovin. All rights reserved.
//

#import "ALBaseAdViewController.h"

@interface ALDemoRewardedVideosViewController : ALBaseAdViewController

@end
