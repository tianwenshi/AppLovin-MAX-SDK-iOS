//
//  ALDemoProgrammaticLeaderViewController.h
//  iOS-SDK-Demo-ObjC
//
//  Created by Santosh Bagadi on 4/4/18.
//  Copyright © 2018 AppLovin. All rights reserved.
//

#import "ALBaseAdViewController.h"

@interface ALDemoProgrammaticLeaderViewController : ALBaseAdViewController

@end
